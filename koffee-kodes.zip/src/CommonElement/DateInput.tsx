import React from 'react'

const DateInput = () => {
  return (
    <div>
      
    </div>
  )
}

export default DateInput
