import React from 'react'

const Customers = () => {
  return (
    <div>
                  <h1 className="text-3xl mb-4">Customers</h1>

    </div>
  )
}

export default Customers
