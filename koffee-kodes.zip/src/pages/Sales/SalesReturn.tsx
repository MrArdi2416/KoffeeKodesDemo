import React from 'react'

const SalesReturn = () => {
  return (
    <div>
            <h1 className="text-3xl mb-4">Sales Return</h1>

    </div>
  )
}

export default SalesReturn
