import React from 'react'

function DeliveryNote() {
  return (
    <div>
       <div>
      <h1 className="text-3xl mb-4">Delivery Note</h1>
      {/* Delivery note content */}
    </div>
    </div>
  )
}

export default DeliveryNote
