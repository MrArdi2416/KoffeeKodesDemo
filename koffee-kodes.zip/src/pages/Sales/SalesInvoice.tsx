import React from 'react'

const SalesInvoice = () => {
  return (
    <div>
            <h1 className="text-3xl mb-4">Sales Invoice</h1>

    </div>
  )
}

export default SalesInvoice
