import React from 'react'

const PurchaseOrder = () => {
  return (
    <div>
        
        <h1 className="text-3xl mb-4">Purchase Order</h1>

    </div>
  )
}

export default PurchaseOrder