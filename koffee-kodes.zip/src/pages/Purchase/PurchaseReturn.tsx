import React from 'react'

const PurchaseReturn = () => {
  return (
    <div>
              <h1 className="text-3xl mb-4">Purchase Return</h1>

    </div>
  )
}

export default PurchaseReturn
