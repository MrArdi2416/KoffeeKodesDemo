import React from 'react'

const PurchaseInvoice = () => {
  return (
    <div>
              <h1 className="text-3xl mb-4">Purchase Invoice</h1>

    </div>
  )
}

export default PurchaseInvoice
